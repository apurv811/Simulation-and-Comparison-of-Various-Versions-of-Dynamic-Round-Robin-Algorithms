package cpu;

/**
 * @author Ahmed Elmowafy
 * Main class of the application that initializes Face Frame.
 */
public class CPU {

    public static void main(String[] args) {
        // TODO code application logic here
            Face face = new Face();
            face.show();
    }
}
